const fs = require("fs");
const path = require("path");

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf-8"));
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function safeSlug(input) {
  return String(input)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function mapDifficulty(value) {
  const v = String(value || "").toLowerCase();
  if (v.includes("hard")) return "HARD";
  if (v.includes("intermediate") || v.includes("medium")) return "MEDIUM";
  return "EASY";
}

function mapProblemType(challengeType) {
  if (challengeType === 8) return "MCQ";
  if (challengeType === 7) return "SUBJECTIVE";
  return "CODING";
}

function getCurriculumRoot() {
  const fromArg = process.argv[2];
  if (fromArg && fromArg.trim()) return fromArg;
  if (process.env.FCC_CURRICULUM_PATH) return process.env.FCC_CURRICULUM_PATH;
  return path.join(process.cwd(), "freeCodeCamp", "curriculum", "challenges", "english");
}

function transformFCC() {
  const curriculumRoot = getCurriculumRoot();
  const outDir = path.join(process.cwd(), "seed-data", "fcc");
  ensureDir(outDir);

  if (!fs.existsSync(curriculumRoot)) {
    throw new Error(`FCC curriculum path not found: ${curriculumRoot}`);
  }

  const superBlockFolders = fs
    .readdirSync(curriculumRoot, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => d.name)
    .sort();

  for (const superBlockFolder of superBlockFolders) {
    const superBlockPath = path.join(curriculumRoot, superBlockFolder);
    const metaPath = path.join(superBlockPath, "_meta.json");
    if (!fs.existsSync(metaPath)) continue;

    const meta = readJson(metaPath);

    const course = {
      externalSource: "FCC",
      externalId: meta.name || superBlockFolder,
      slug: safeSlug(meta.title || meta.name || superBlockFolder),
      title: meta.title || meta.name || superBlockFolder,
      description: "Imported from freeCodeCamp",
      level: "BEGINNER",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const problems = [];
    const modulesByName = new Map();
    const problemSets = [];
    const problemSetItems = [];

    let nextProblemId = 1;
    let nextModuleId = 1;
    let nextProblemSetItemId = 1;

    const jsonFiles = fs
      .readdirSync(superBlockPath)
      .filter((f) => f.endsWith(".json") && f !== "_meta.json")
      .sort();

    for (const fileName of jsonFiles) {
      const filePath = path.join(superBlockPath, fileName);
      const content = readJson(filePath);
      const challenges = Array.isArray(content.challenges) ? content.challenges : [];

      for (const ch of challenges) {
        const moduleName = ch.block || "General";

        if (!modulesByName.has(moduleName)) {
          const moduleId = nextModuleId++;
          const problemSetCode = `${course.externalId}:${safeSlug(moduleName)}`;

          modulesByName.set(moduleName, {
            id: moduleId,
            name: moduleName,
            description: "Imported from freeCodeCamp",
            orderIndex: modulesByName.size + 1,
            assessmentId: problemSetCode,
            submodules: [],
            problemSetCode,
          });

          problemSets.push({
            code: problemSetCode,
            name: moduleName,
            type: "PRACTICE",
            description: "Imported from freeCodeCamp",
            durationMinutes: 0,
          });
        }

        const module = modulesByName.get(moduleName);

        const problemExternalId = ch.id || ch._id || null;
        const problemCode = String(ch.title || ch.dashedName || "problem")
          .replace(/\s+/g, " ")
          .trim();

        const problem = {
          id: nextProblemId++,
          externalSource: "FCC",
          externalId: problemExternalId,
          code: problemExternalId || `FCC-${nextProblemId - 1}`,
          name: ch.title || ch.name || "Untitled",
          slug: safeSlug(ch.dashedName || ch.title || "untitled"),
          body: ch.description || "",
          type: mapProblemType(ch.challengeType),
          difficulty: mapDifficulty(ch.difficulty || ch.difficultyRange),
          author: "freeCodeCamp",
          maxScore: typeof ch.points === "number" ? ch.points : 0,
          tags: Array.isArray(ch.tags) ? ch.tags : null,
          mcqOptions: null,
          codingConfig: {
            challengeType: ch.challengeType,
            tests: Array.isArray(ch.tests) ? ch.tests : [],
            question: ch.question || null,
            solutions: Array.isArray(ch.solutions) ? ch.solutions : [],
          },
          videoUrl: ch.videoUrl || null,
          editorialUrl: ch.helpUrl || null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        problems.push(problem);

        problemSetItems.push({
          id: nextProblemSetItemId++,
          problemSetCode: module.problemSetCode,
          problemId: problem.id,
          orderIndex: problemSetItems.filter((x) => x.problemSetCode === module.problemSetCode).length + 1,
        });
      }
    }

    const modules = Array.from(modulesByName.values()).map((m) => {
      const { problemSetCode, ...rest } = m;
      return rest;
    });

    const out = {
      course,
      modules,
      problemSets,
      problems,
      problemSetItems,
    };

    const fileBase = safeSlug(course.title) || safeSlug(course.externalId);
    const outPath = path.join(outDir, `${fileBase}.json`);
    fs.writeFileSync(outPath, JSON.stringify(out, null, 2), "utf-8");
  }

  return { ok: true };
}

try {
  transformFCC();
  process.stdout.write("FCC transform completed.\n");
} catch (err) {
  process.stderr.write(String(err && err.stack ? err.stack : err));
  process.stderr.write("\n");
  process.exit(1);
}
